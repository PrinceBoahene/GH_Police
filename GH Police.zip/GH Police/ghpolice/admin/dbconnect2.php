<?php  
$dbcon = mysqli_connect ("localhost", "root", "", "ghpolice");
mysqli_set_charset($dbcon, 'utf8'); 

?>